
%% 

function [reg_max,cacv,x_dec] = eir_2021(U,iter,...
    pro_a,b_out,f_obj,...
    beta_step,epsi,eta_reg,...
    full_or_bandit)

m = 2;
n = 20;
p = 2*m;        
L = -U;
R = sqrt(m)*U;

threshold = 0.3800;
rand('state',35);
xy = rand(n,2);

angle = 10*pi/180;
Rotate = [ cos(angle) sin(angle); -sin(angle) cos(angle) ];
xy = (Rotate*xy')';

Dist = zeros(n,n);
for i=1:(n-1);
    for j=i+1:n;
        Dist(i,j) = norm( xy(i,:) - xy(j,:) );
    end;
end;
Dist = Dist + Dist';
Ad = Dist < threshold;
Ad = Ad - eye(n);
m_edge = sum(sum(Ad))/2;


A = zeros(n,m_edge);
l = 0;
for i=1:(n-1);
    for j=i+1:n;
        if Ad(i,j)>0.5
            l = l + 1;
            A(i,l) =  1;
            A(j,l) = -1;
        end;
    end;
end;
A = sparse(A);

[ WM ]  = max_deg_eir(A);


% % plot the graph
% figure(1), clf
% gplot(Ad,xy);
% hold on;
% plot(xy(:,1), xy(:,2), 'ro','LineWidth',5, 'MarkerSize',4);
% axis([0.00 1.20 -0.15 1.00]);
% axis off; % turn off the axis
% % title('The network')
% hold off;


rng(1,'twister');
x_dec = rand(m,n);
reg_vec = zeros(n,1);         

dual_dec = zeros(p,n);
for y = 1 : n
    for s = 1 : m
        cacv = max(L - x_dec(s,y),0) + max(x_dec(s,y) - U,0);
    end
end

f_val = zeros(n,1);
for i = 1 : n
    for j = 1 : n
        f_val(i) = f_val(i) +...
            (1/2)*( pro_a(:,j,1)'*x_dec(:,i) - b_out(j,1) )^2;
    end
end

for t = 2 : iter
    for j = 1 : n
        subg = ( pro_a(:,j,t)'*x_dec(:,j) - b_out(j,t))*pro_a(:,j,t);
        ran_vec = randn(m,1);
        ran_vec = ran_vec./norm(ran_vec,2);
        x_dec_t1 = x_dec(:,j) + epsi*ran_vec;
        subg_ban = (1/2)*( pro_a(:,j,t)'*x_dec_t1 - b_out(j,t) )^2*...
            (m/(epsi))*ran_vec;
        
        if full_or_bandit == 1
            x_dec(:,j) = x_dec(:,j) - beta_step*( subg +...
                dual_dec(:,j)'*iclr_sub_ineqs(m,x_dec(:,j),L,U) );
        else
            x_dec(:,j) = x_dec(:,j) - beta_step*( subg_ban +...
                dual_dec(:,j)'*iclr_sub_ineqs(m,x_dec(:,j),L,U) );
        end
    end
    
    x_dec = x_dec*WM';
    
    for l = 1 : n
        x_dec(:,l) = ( R/max(norm(x_dec(:,l)),R) )*x_dec(:,l);
        for s = 1 : m
            dual_dec(s,l) = max(L - x_dec(s,l),0)/eta_reg;
            dual_dec(s+m,l) = max(x_dec(s,l)-U,0)/eta_reg;
        end
    end
    
    for y = 1 : n
        for u = 1 : m
            cacv = cacv + max(L - x_dec(u,y),0) + max(x_dec(u,y) - U,0);
        end
    end
    
    for i = 1 : n
        for p = 1 : n
            f_val(i) = f_val(i) +...
                (1/2)*( pro_a(:,p,t)'*x_dec(:,i) - b_out(p,t) )^2;
        end
    end
    
end

for i = 1 : n
    reg_vec(i) = f_val(i) - f_obj;
end
reg_max = max(reg_vec);




