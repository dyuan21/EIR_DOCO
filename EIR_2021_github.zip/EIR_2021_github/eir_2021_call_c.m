%% 

function [] = eir_2021_call_c()
c = 1/2;
T = 200;

[Reg_cS,RegB_cS,cacv_cS,cacvB_cS] = eir_2021_call(c,T);

h1 = line_fewer_markers( 1:T, Reg_cS, 8,'o-b','MarkerSize', 7, 'linewidth', 1.5);
h2 = line_fewer_markers( 1:T, RegB_cS, 8,'^-r','MarkerSize', 7, 'linewidth', 1.5);
h3 = line_fewer_markers( 1:T, cacv_cS, 8,'o--b','MarkerSize', 7, 'linewidth', 1.5);
h4 = line_fewer_markers( 1:T, cacvB_cS, 8,'^--r','MarkerSize', 7, 'linewidth', 1.5);
legend([h1 h2 h3 h4],...
    'MAR: full information','MAR: bandit',...
    'CACV: full information','CACV: bandit');

grid on;
xlabel('Time Horizon T');
% ylabel('Maximum Regret');
set(gca, 'YScale', 'log');


