%% 

function [Reg_T,Reg_TB,CACV_T,CACV_TB] = eir_2021_call(c,T)
m = 2;
n = 20;
U = 1/2;
b = c/3;

c_eta_reg = 1; 
c_beta_step = .5;  
c_epsi = 1;  
eta_reg = zeros(1,T);
beta_step = zeros(1,T);
epsi = zeros(1,T);


for s = 1 : T
    eta_reg(s) = 1/(c_eta_reg*(s^c));
    beta_step(s) = 1/(c_beta_step*(s^c));
    epsi(s) = 1/(c_epsi*(s^b));
end

rng(1,'twister');
pro_a = 1 + (-2)*rand(m,n,T);

rng(1,'twister');
b_out = rand(n,T);



f_opt = zeros(T,1);
x_opt = zeros(m,T);    
x_t_opt = zeros(m,T); 
pro1 = zeros(m,m);
pro2 = zeros(m,1);
pro3 = 0;
for t = 1 : T
    for p = 1 : n
        pro1 = pro1 + pro_a(:,p,t)*pro_a(:,p,t)';
        pro2 = pro2 + b_out(p,t)*pro_a(:,p,t);
        pro3 = pro3 + b_out(p,t)^2;
    end
    x_opt(:,t) = pro1\pro2;
    x_opt(:,t) = box_proj(m,x_opt(:,t),-U,U);
    f_opt(t) = (1/2)*x_opt(:,t)'*pro1*x_opt(:,t) - pro2'*x_opt(:,t) + (1/2)*pro3;
    
    pro1_t = zeros(m,m);
    pro2_t = zeros(m,1);
    for q = 1 : n
        pro1_t = pro1_t + pro_a(:,q,t)*pro_a(:,q,t)';
        pro2_t = pro2_t + b_out(q,t)*pro_a(:,q,t);
    end
    x_t_opt(:,t) = pro1_t\pro2_t;
    x_t_opt(:,t) = box_proj(m,x_t_opt(:,t),-U,U);
end


Reg_T = zeros(1,T);
Reg_TB = zeros(1,T);
CACV_T = zeros(1,T);
CACV_TB = zeros(1,T);
x_DEC = zeros(m,T);
x_DEC_2 = zeros(m,T);
x_DEC_B = zeros(m,T);

for t = 1 : T
    [Reg_T(t),CACV_T(t),x_temp] =  eir_2021(U,t,...
        pro_a(:,:,1:t),b_out(:,1:t),f_opt(t),...
        beta_step(t),epsi(t),eta_reg(t),1);
    Reg_T(t) = Reg_T(t)/t;
    CACV_T(t) = CACV_T(t)/t;
    x_DEC(:,t) = x_temp(:,12);
    x_DEC_2(:,t) = x_temp(:,15);
    [Reg_TB(t),CACV_TB(t),x_temp_B] = eir_2021(U,t,...
        pro_a(:,:,1:t),b_out(:,1:t),f_opt(t),...
        beta_step(t),epsi(t),eta_reg(t),2);
    Reg_TB(t) = Reg_TB(t)/t;
    CACV_TB(t) = CACV_TB(t)/t;
    x_DEC_B(:,t) = x_temp_B(:,11)';
end








